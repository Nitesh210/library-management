# import viewsets
from urllib import response
import django
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework.decorators import api_view

# import local data
from .serializers import librarySerializer
from .models import libraryModel

# create a viewset
class libraryViewSet(viewsets.ModelViewSet):
	# define queryset

	queryset = libraryModel.objects.all()
	http_method_names = ['get', 'put', 'post', 'head', 'options', 'trace', 'delete',]
	# specify serializer to be used
	serializer_class = librarySerializer
from django.shortcuts import render

# Create your views here.

def index(request):
    # create a dictionary to pass
    # data to the template
    context ={
        "data":"Gfg is the best",
        "list":[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    }
    # return response with template and context
    return render(request, "index.html", context)

